#pragma once
#include <string>
#include <vector>

class Book {
public:
    Book(int id, std::string title, std::string author, bool available = true);

    int id() const;
    const std::string& title() const;
    const std::string& author() const;
    bool isAvailable() const;
    void setAvailable(bool available);
    bool matches(const std::string& query) const;
    std::string toRecord() const;
    static Book fromFields(const std::vector<std::string>& fields);

private:
    int id_;
    std::string title_;
    std::string author_;
    bool available_;
};
