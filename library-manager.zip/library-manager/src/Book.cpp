#include "Book.h"
#include "Utils.h"

#include <stdexcept>

Book::Book(int id, std::string title, std::string author, bool available)
    : id_(id), title_(std::move(title)), author_(std::move(author)), available_(available) {}

int Book::id() const { return id_; }
const std::string& Book::title() const { return title_; }
const std::string& Book::author() const { return author_; }
bool Book::isAvailable() const { return available_; }
void Book::setAvailable(bool available) { available_ = available; }

bool Book::matches(const std::string& query) const {
    std::string haystack = util::toLower(title_ + " " + author_);
    return haystack.find(util::toLower(query)) != std::string::npos;
}

std::string Book::toRecord() const {
    return "BOOK," + std::to_string(id_) + "," + title_ + "," + author_ + "," +
           (available_ ? "1" : "0");
}

Book Book::fromFields(const std::vector<std::string>& fields) {
    if (fields.size() != 5) throw std::invalid_argument("bad book record");
    int id = std::stoi(fields[1]);
    if (id <= 0 || fields[2].empty()) throw std::invalid_argument("bad book record");
    return Book(id, fields[2], fields[3], fields[4] == "1");
}
