#pragma once
#include <string>
#include <vector>

class Loan {
public:
    Loan(int id, int bookId, int memberId, std::string issueDate, std::string returnDate = "");

    int id() const;
    int bookId() const;
    int memberId() const;
    const std::string& issueDate() const;
    const std::string& returnDate() const;
    bool isActive() const;
    void markReturned(const std::string& date);
    std::string toRecord() const;
    static Loan fromFields(const std::vector<std::string>& fields);

private:
    int id_;
    int bookId_;
    int memberId_;
    std::string issueDate_;
    std::string returnDate_;
};
