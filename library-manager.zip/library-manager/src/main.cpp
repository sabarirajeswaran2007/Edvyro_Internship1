#include "Library.h"
#include "Utils.h"

#include <climits>
#include <iomanip>
#include <iostream>

namespace {

void printMenu() {
    std::cout << "\n===== Library Manager =====\n"
              << "1. Add book\n"
              << "2. Add member\n"
              << "3. Issue book\n"
              << "4. Return book\n"
              << "5. Search books\n"
              << "6. List available books\n"
              << "7. List all books\n"
              << "8. List members\n"
              << "9. List active loans\n"
              << "0. Exit\n";
}

void printBooks(const std::vector<const Book*>& books) {
    if (books.empty()) {
        std::cout << "No books found.\n";
        return;
    }
    std::cout << std::left << std::setw(5) << "ID" << std::setw(34) << "Title" << std::setw(24)
              << "Author" << "Status\n"
              << std::string(72, '-') << "\n";
    for (const Book* b : books)
        std::cout << std::left << std::setw(5) << b->id() << std::setw(34)
                  << b->title().substr(0, 32) << std::setw(24) << b->author().substr(0, 22)
                  << (b->isAvailable() ? "Available" : "On loan") << "\n";
}

void printMembers(const Library& library) {
    if (library.members().empty()) {
        std::cout << "No members registered.\n";
        return;
    }
    std::cout << std::left << std::setw(5) << "ID" << std::setw(30) << "Name" << "Active loans\n"
              << std::string(48, '-') << "\n";
    for (const Member& m : library.members())
        std::cout << std::left << std::setw(5) << m.id() << std::setw(30) << m.name()
                  << library.activeLoanCount(m.id()) << "\n";
}

void printLoans(const Library& library) {
    std::vector<const Loan*> loans = library.activeLoans();
    if (loans.empty()) {
        std::cout << "No active loans.\n";
        return;
    }
    std::cout << std::left << std::setw(6) << "Loan" << std::setw(32) << "Book" << std::setw(20)
              << "Member" << "Issued\n"
              << std::string(70, '-') << "\n";
    for (const Loan* l : loans)
        std::cout << std::left << std::setw(6) << l->id() << std::setw(32)
                  << library.findBook(l->bookId())->title().substr(0, 30) << std::setw(20)
                  << library.findMember(l->memberId())->name().substr(0, 18) << l->issueDate()
                  << "\n";
}

void persist(const Library& library) {
    if (!library.save()) std::cout << "Warning: could not save data to disk.\n";
}

}

int main(int argc, char* argv[]) {
    std::string dataFile = argc > 1 ? argv[1] : "data/library.csv";
    Library library(dataFile);
    if (library.load()) std::cout << "Loaded records from " << dataFile << "\n";
    else std::cout << "No data file found. Starting with an empty library.\n";

    bool running = true;
    while (running) {
        printMenu();
        int choice = util::readInt("Choose an option (0-9): ", 0, 9);
        std::string message;
        switch (choice) {
            case 1: {
                std::string title = util::readNonEmpty("Title: ");
                std::string author = util::readNonEmpty("Author: ");
                std::cout << "Added book with ID " << library.addBook(title, author) << ".\n";
                persist(library);
                break;
            }
            case 2: {
                std::string name = util::readNonEmpty("Member name: ");
                std::cout << "Added member with ID " << library.addMember(name) << ".\n";
                persist(library);
                break;
            }
            case 3: {
                int memberId = util::readInt("Member ID: ", 1, INT_MAX);
                int bookId = util::readInt("Book ID: ", 1, INT_MAX);
                bool ok = library.issueBook(bookId, memberId, message);
                std::cout << message << "\n";
                if (ok) persist(library);
                break;
            }
            case 4: {
                int bookId = util::readInt("Book ID: ", 1, INT_MAX);
                bool ok = library.returnBook(bookId, message);
                std::cout << message << "\n";
                if (ok) persist(library);
                break;
            }
            case 5:
                printBooks(library.search(util::readNonEmpty("Search title or author: ")));
                break;
            case 6: printBooks(library.availableBooks()); break;
            case 7: printBooks(library.allBooks()); break;
            case 8: printMembers(library); break;
            case 9: printLoans(library); break;
            case 0: running = false; break;
        }
    }
    persist(library);
    std::cout << "Goodbye!\n";
    return 0;
}
