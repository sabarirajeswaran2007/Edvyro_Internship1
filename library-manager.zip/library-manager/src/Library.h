#pragma once
#include "Book.h"
#include "Loan.h"
#include "Member.h"

#include <string>
#include <vector>

class Library {
public:
    static const int MAX_LOANS = 3;

    explicit Library(std::string dataFile);

    bool load();
    bool save() const;

    int addBook(const std::string& title, const std::string& author);
    int addMember(const std::string& name);
    bool issueBook(int bookId, int memberId, std::string& message);
    bool returnBook(int bookId, std::string& message);

    std::vector<const Book*> search(const std::string& query) const;
    std::vector<const Book*> availableBooks() const;
    std::vector<const Book*> allBooks() const;
    std::vector<const Loan*> activeLoans() const;
    int activeLoanCount(int memberId) const;

    const Book* findBook(int id) const;
    const Member* findMember(int id) const;
    const std::vector<Member>& members() const;

private:
    Book* mutableBook(int id);
    Loan* activeLoanForBook(int bookId);
    void reconcile();

    std::string dataFile_;
    std::vector<Book> books_;
    std::vector<Member> members_;
    std::vector<Loan> loans_;
    int nextBookId_ = 1;
    int nextMemberId_ = 1;
    int nextLoanId_ = 1;
};
