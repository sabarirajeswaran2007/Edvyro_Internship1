#pragma once
#include <string>
#include <vector>

namespace util {

std::string trim(const std::string& s);
std::string toLower(std::string s);
std::string sanitize(std::string s);
std::vector<std::string> split(const std::string& line, char delim);
std::string today();
std::string readLine(const std::string& prompt);
std::string readNonEmpty(const std::string& prompt);
int readInt(const std::string& prompt, int low, int high);

}
