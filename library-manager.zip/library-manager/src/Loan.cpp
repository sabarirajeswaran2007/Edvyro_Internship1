#include "Loan.h"

#include <stdexcept>

Loan::Loan(int id, int bookId, int memberId, std::string issueDate, std::string returnDate)
    : id_(id), bookId_(bookId), memberId_(memberId),
      issueDate_(std::move(issueDate)), returnDate_(std::move(returnDate)) {}

int Loan::id() const { return id_; }
int Loan::bookId() const { return bookId_; }
int Loan::memberId() const { return memberId_; }
const std::string& Loan::issueDate() const { return issueDate_; }
const std::string& Loan::returnDate() const { return returnDate_; }
bool Loan::isActive() const { return returnDate_.empty(); }
void Loan::markReturned(const std::string& date) { returnDate_ = date; }

std::string Loan::toRecord() const {
    return "LOAN," + std::to_string(id_) + "," + std::to_string(bookId_) + "," +
           std::to_string(memberId_) + "," + issueDate_ + "," + returnDate_;
}

Loan Loan::fromFields(const std::vector<std::string>& fields) {
    if (fields.size() != 6) throw std::invalid_argument("bad loan record");
    int id = std::stoi(fields[1]);
    int bookId = std::stoi(fields[2]);
    int memberId = std::stoi(fields[3]);
    if (id <= 0 || bookId <= 0 || memberId <= 0 || fields[4].empty())
        throw std::invalid_argument("bad loan record");
    return Loan(id, bookId, memberId, fields[4], fields[5]);
}
