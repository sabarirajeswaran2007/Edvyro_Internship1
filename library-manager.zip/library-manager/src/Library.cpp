#include "Library.h"
#include "Utils.h"

#include <algorithm>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <stdexcept>

Library::Library(std::string dataFile) : dataFile_(std::move(dataFile)) {}

bool Library::load() {
    std::ifstream in(dataFile_);
    if (!in) return false;
    books_.clear();
    members_.clear();
    loans_.clear();
    std::string line;
    int lineNo = 0;
    while (std::getline(in, line)) {
        ++lineNo;
        line = util::trim(line);
        if (line.empty() || line[0] == '#') continue;
        try {
            std::vector<std::string> fields = util::split(line, ',');
            if (fields[0] == "BOOK") books_.push_back(Book::fromFields(fields));
            else if (fields[0] == "MEMBER") members_.push_back(Member::fromFields(fields));
            else if (fields[0] == "LOAN") loans_.push_back(Loan::fromFields(fields));
            else throw std::invalid_argument("unknown record type");
        } catch (const std::exception&) {
            std::cerr << "Skipping invalid record on line " << lineNo << "\n";
        }
    }
    reconcile();
    return true;
}

void Library::reconcile() {
    loans_.erase(std::remove_if(loans_.begin(), loans_.end(),
                                [this](const Loan& l) {
                                    return !findBook(l.bookId()) || !findMember(l.memberId());
                                }),
                 loans_.end());
    for (Book& b : books_) b.setAvailable(true);
    for (const Loan& l : loans_)
        if (l.isActive()) mutableBook(l.bookId())->setAvailable(false);
    nextBookId_ = nextMemberId_ = nextLoanId_ = 1;
    for (const Book& b : books_) nextBookId_ = std::max(nextBookId_, b.id() + 1);
    for (const Member& m : members_) nextMemberId_ = std::max(nextMemberId_, m.id() + 1);
    for (const Loan& l : loans_) nextLoanId_ = std::max(nextLoanId_, l.id() + 1);
}

bool Library::save() const {
    std::filesystem::path target(dataFile_);
    std::error_code ec;
    if (target.has_parent_path()) std::filesystem::create_directories(target.parent_path(), ec);
    std::filesystem::path temp = target;
    temp += ".tmp";
    {
        std::ofstream out(temp);
        if (!out) return false;
        out << "# BOOK,id,title,author,available\n"
            << "# MEMBER,id,name\n"
            << "# LOAN,id,bookId,memberId,issueDate,returnDate\n";
        for (const Book& b : books_) out << b.toRecord() << "\n";
        for (const Member& m : members_) out << m.toRecord() << "\n";
        for (const Loan& l : loans_) out << l.toRecord() << "\n";
        out.flush();
        if (!out) return false;
    }
    std::filesystem::rename(temp, target, ec);
    return !ec;
}

int Library::addBook(const std::string& title, const std::string& author) {
    books_.emplace_back(nextBookId_, util::sanitize(title), util::sanitize(author));
    return nextBookId_++;
}

int Library::addMember(const std::string& name) {
    members_.emplace_back(nextMemberId_, util::sanitize(name));
    return nextMemberId_++;
}

bool Library::issueBook(int bookId, int memberId, std::string& message) {
    Book* book = mutableBook(bookId);
    if (!book) {
        message = "No book with ID " + std::to_string(bookId) + ".";
        return false;
    }
    const Member* member = findMember(memberId);
    if (!member) {
        message = "No member with ID " + std::to_string(memberId) + ".";
        return false;
    }
    if (!book->isAvailable()) {
        message = "'" + book->title() + "' is already on loan.";
        return false;
    }
    if (activeLoanCount(memberId) >= MAX_LOANS) {
        message = member->name() + " has reached the limit of " + std::to_string(MAX_LOANS) +
                  " active loans.";
        return false;
    }
    loans_.emplace_back(nextLoanId_++, bookId, memberId, util::today());
    book->setAvailable(false);
    message = "Issued '" + book->title() + "' to " + member->name() + ".";
    return true;
}

bool Library::returnBook(int bookId, std::string& message) {
    Book* book = mutableBook(bookId);
    if (!book) {
        message = "No book with ID " + std::to_string(bookId) + ".";
        return false;
    }
    Loan* loan = activeLoanForBook(bookId);
    if (!loan) {
        message = "'" + book->title() + "' is not currently on loan.";
        return false;
    }
    loan->markReturned(util::today());
    book->setAvailable(true);
    message = "Returned '" + book->title() + "'.";
    return true;
}

std::vector<const Book*> Library::search(const std::string& query) const {
    std::vector<const Book*> results;
    for (const Book& b : books_)
        if (b.matches(query)) results.push_back(&b);
    return results;
}

std::vector<const Book*> Library::availableBooks() const {
    std::vector<const Book*> results;
    for (const Book& b : books_)
        if (b.isAvailable()) results.push_back(&b);
    return results;
}

std::vector<const Book*> Library::allBooks() const {
    std::vector<const Book*> results;
    for (const Book& b : books_) results.push_back(&b);
    return results;
}

std::vector<const Loan*> Library::activeLoans() const {
    std::vector<const Loan*> results;
    for (const Loan& l : loans_)
        if (l.isActive()) results.push_back(&l);
    return results;
}

int Library::activeLoanCount(int memberId) const {
    return static_cast<int>(std::count_if(loans_.begin(), loans_.end(), [memberId](const Loan& l) {
        return l.isActive() && l.memberId() == memberId;
    }));
}

const Book* Library::findBook(int id) const {
    for (const Book& b : books_)
        if (b.id() == id) return &b;
    return nullptr;
}

const Member* Library::findMember(int id) const {
    for (const Member& m : members_)
        if (m.id() == id) return &m;
    return nullptr;
}

const std::vector<Member>& Library::members() const { return members_; }

Book* Library::mutableBook(int id) {
    for (Book& b : books_)
        if (b.id() == id) return &b;
    return nullptr;
}

Loan* Library::activeLoanForBook(int bookId) {
    for (Loan& l : loans_)
        if (l.isActive() && l.bookId() == bookId) return &l;
    return nullptr;
}
