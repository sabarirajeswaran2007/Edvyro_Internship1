#pragma once
#include <string>
#include <vector>

class Member {
public:
    Member(int id, std::string name);

    int id() const;
    const std::string& name() const;
    std::string toRecord() const;
    static Member fromFields(const std::vector<std::string>& fields);

private:
    int id_;
    std::string name_;
};
