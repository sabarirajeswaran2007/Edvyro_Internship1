#include "Utils.h"

#include <algorithm>
#include <cctype>
#include <cstdlib>
#include <ctime>
#include <iostream>

namespace util {

std::string trim(const std::string& s) {
    size_t start = s.find_first_not_of(" \t\r\n");
    if (start == std::string::npos) return "";
    size_t end = s.find_last_not_of(" \t\r\n");
    return s.substr(start, end - start + 1);
}

std::string toLower(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(),
                   [](unsigned char c) { return std::tolower(c); });
    return s;
}

std::string sanitize(std::string s) {
    std::replace(s.begin(), s.end(), ',', ' ');
    std::replace(s.begin(), s.end(), '\n', ' ');
    std::replace(s.begin(), s.end(), '\r', ' ');
    return trim(s);
}

std::vector<std::string> split(const std::string& line, char delim) {
    std::vector<std::string> fields;
    size_t start = 0;
    while (true) {
        size_t pos = line.find(delim, start);
        if (pos == std::string::npos) {
            fields.push_back(line.substr(start));
            break;
        }
        fields.push_back(line.substr(start, pos - start));
        start = pos + 1;
    }
    return fields;
}

std::string today() {
    std::time_t now = std::time(nullptr);
    char buffer[16];
    std::strftime(buffer, sizeof(buffer), "%Y-%m-%d", std::localtime(&now));
    return buffer;
}

std::string readLine(const std::string& prompt) {
    std::string line;
    std::cout << prompt;
    if (!std::getline(std::cin, line)) {
        std::cout << "\nInput closed. Exiting.\n";
        std::exit(0);
    }
    return trim(line);
}

std::string readNonEmpty(const std::string& prompt) {
    while (true) {
        std::string value = sanitize(readLine(prompt));
        if (!value.empty()) return value;
        std::cout << "Input cannot be empty.\n";
    }
}

int readInt(const std::string& prompt, int low, int high) {
    while (true) {
        std::string line = readLine(prompt);
        try {
            size_t pos = 0;
            int value = std::stoi(line, &pos);
            if (pos == line.size() && value >= low && value <= high) return value;
        } catch (const std::exception&) {
        }
        std::cout << "Enter a whole number between " << low << " and " << high << ".\n";
    }
}

}
