#include "Member.h"

#include <stdexcept>

Member::Member(int id, std::string name) : id_(id), name_(std::move(name)) {}

int Member::id() const { return id_; }
const std::string& Member::name() const { return name_; }

std::string Member::toRecord() const {
    return "MEMBER," + std::to_string(id_) + "," + name_;
}

Member Member::fromFields(const std::vector<std::string>& fields) {
    if (fields.size() != 3) throw std::invalid_argument("bad member record");
    int id = std::stoi(fields[1]);
    if (id <= 0 || fields[2].empty()) throw std::invalid_argument("bad member record");
    return Member(id, fields[2]);
}
